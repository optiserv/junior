<?php

namespace App\db\initial;

function initializeDb($db)
{
    //TODO: Create initial tables
}
