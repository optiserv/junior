<?php

namespace App;

use App\Models\User;
use App\Models\Post;
use App\db\DB;

class Api
{
    public function connection()
    {
        //TODO: Implement api: get user by id, create user
    }
}
